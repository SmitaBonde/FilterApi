﻿using System.Collections.Generic;
using System.Threading.Tasks;
using NUnit.Framework;
using NSubstitute;
using FluentAssertions;
using FilterApi.Controllers;
using FilterApi.Services;
using FilterApi.Models;

namespace FilterAPITests
{
    [TestFixture]
    public class FilterControllerTests
    {
        private IDataRepository _dataRepository;
        private FilterController _controller;

        [SetUp]
        public void Setup()
        {
            _dataRepository = Substitute.For<IDataRepository>();
            _controller = new FilterController(_dataRepository);
        }

        [Test]
        public async Task Get_ShouldReturnFilteredProducts()
        {
            var toBeFiltered = new Product("Title2", 20, new List<string>() { "small", "medium" }, "y b one a two z three a x four b a y five z six z seven x eight b x nine y one two x three a z four y five six one two x three");
            
            var productsList = new ProductsList();
            productsList.Products = new List<Product>()
            {
                new Product("Title1", 10, new List<string>() { "small", "large" }, "y b one x y z a b two b z three x four y a five x b six y seven x b eight a z one x two z a three x four y five six y seven one two three four"),
                toBeFiltered,
                new Product("Title3", 30, new List<string>() { "medium", "large" }, "y b one z two x a three x z four z five b six z seven b a x eight z y nine a ten y one a two y three x four five x one two one")
            };

            _dataRepository.GetProducts().Returns(productsList);

            var expectedResult = new FilterResponse();
            expectedResult.MinPriceAmongAllProducts = 10;
            expectedResult.MaxPriceAmongAllProducts = 30;
            expectedResult.AllAvailableSizes = new string[] { "small", "medium", "large" };
            expectedResult.MostCommonWords = new string[] { "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten" };
            expectedResult.Products = new List<Product>() { toBeFiltered };

            var response = await _controller.Get(size: "small", highlight: string.Empty, minPrice: 15, maxPrice: 25);

            response.Should().BeEquivalentTo(expectedResult);
        }
    }
}