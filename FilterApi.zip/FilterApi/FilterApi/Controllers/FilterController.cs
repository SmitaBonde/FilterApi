﻿using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using FilterApi.Models;
using FilterApi.Services;

namespace FilterApi.Controllers
{
    /// <summary>
    /// FilterController for filter endpoint
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class FilterController : ControllerBase
    {
        private readonly IDataRepository _dataRepository;

        /// <summary>
        /// Dependency injection of DataRepository to read the json data from http location
        /// </summary>
        /// <param name="dataRepository"></param>
        public FilterController(IDataRepository dataRepository)
        {
            _dataRepository = dataRepository;
        }

        // GET api/filter
        /// <summary>
        /// Accepts a GET request with three optional query parameters to filter products or highlight some words(separated by commas in the query parameter) in their description
        /// </summary>
        /// <param name="size"></param>
        /// <param name="highlight"></param>
        /// <param name="minPrice"></param>
        /// <param name="maxPrice"></param>
        /// <returns>FilterResponse</returns>
        [HttpGet]
        public async Task<FilterResponse> Get(
            string size,
            string highlight,
            int minPrice = 0,
            int maxPrice = 0)
        {
            var result = new FilterResponse();

            var allProducts = await _dataRepository.GetProducts();

            result.MinPriceAmongAllProducts = allProducts.Products.Min(p => p.Price);
            result.MaxPriceAmongAllProducts = allProducts.Products.Max(p => p.Price);
            result.AllAvailableSizes = allProducts.Products.SelectMany(p => p.Sizes.Select(s => s)).Distinct().ToArray();
            result.MostCommonWords = ExtractCommonWords(allProducts);

            List<Product> filteredProducts = ApplyFilters(size, minPrice, maxPrice, allProducts);

            if (string.IsNullOrEmpty(highlight))
            {
                result.Products = filteredProducts;
            }
            else
            {
                ApplyHighlights(highlight, result, filteredProducts);
            }

            return result;
        }

        private static List<Product> ApplyFilters(string size, int minPrice, int maxPrice, ProductsList allProducts)
        {
            var filteredProducts = new List<Product>();

            if (maxPrice == 0)
            {
                maxPrice = allProducts.Products.Max(f => f.Price);
            }

            if (string.IsNullOrEmpty(size))
            {
                filteredProducts = allProducts.Products.Where(
                    p => p.Price >= minPrice
                    && p.Price <= maxPrice)
                    .Select(P => P)
                    .ToList();
            }
            else
            {
                filteredProducts = allProducts.Products.Where(
                    p => p.Price >= minPrice
                    && p.Price <= maxPrice
                    && p.Sizes.Contains(size))
                    .Select(P => P)
                    .ToList();
            }

            return filteredProducts;
        }

        private static string[] ExtractCommonWords(ProductsList allProducts)
        {
            var words = allProducts.Products.Select(p => p.Description).ToList();

            string joinedWords = words.Aggregate((x, y) => x + " " + y);

            var orderedWords = joinedWords
                .Replace(".", "")
                .Split(' ')
                .GroupBy(x => x)
                .Select(x => new
                {
                    KeyField = x.Key,
                    Count = x.Count()
                })
                .OrderByDescending(x => x.Count)
                .Take(15)
                .TakeLast(10);

           return orderedWords.Select(w => w.KeyField).ToArray();
        }

        private static void ApplyHighlights(string highlight, FilterResponse result, List<Product> filteredProducts)
        {
            var filteredProductsToBeHighlighted = new List<Product>();

            var highlightedWords = highlight.Split(',');

            foreach (var product in filteredProducts)
            {
                var description = product.Description;

                foreach (var word in highlightedWords)
                {
                    string replaceWord = "<em>" + word + "</em>";
                    description = description.Replace(word, replaceWord);
                }

                filteredProductsToBeHighlighted.Add(
                    new Product(product.Title, product.Price, product.Sizes, description));
            }

            result.Products = filteredProductsToBeHighlighted;
        }
    }
}
