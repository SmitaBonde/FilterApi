﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace FilterApi.Models
{
    public class FilterResponse
    {
        [DataMember(Name = "minPriceAmongAllProducts")]
        public int MinPriceAmongAllProducts { get; set; }

        [DataMember(Name = "maxPriceAmongAllProducts")]
        public int MaxPriceAmongAllProducts { get; set; }

        [DataMember(Name = "allAvailableSizes")]
        public string[] AllAvailableSizes { get; set; }

        [DataMember(Name = "mostCommonWords")]
        public string[] MostCommonWords { get; set; }

        [DataMember(Name = "products")]
        public ICollection<Product> Products { get; set; }
    }
}