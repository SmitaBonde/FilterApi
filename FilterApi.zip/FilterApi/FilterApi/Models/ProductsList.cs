﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace FilterApi.Models
{
    [DataContract]
    public class ProductsList
    {
        [DataMember(Name = "products")]
        public ICollection<Product> Products { get; set; }
    }
}
