﻿namespace FilterApi.Models
{
    public class DataUrlOptions
    {
        public string Url { get; set; }
    }
}