﻿using System.Runtime.Serialization;

namespace FilterApi.Models
{
    public enum Size
    {
        [EnumMember(Value = "small")]
        Small,

        [EnumMember(Value = "medium")]
        Medium,

        [EnumMember(Value = "large")]
        Large
    }
}