﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace FilterApi.Models
{
    [DataContract]
    public class Product
    {
        public Product(
            string title,
            int price,
            ICollection<string> sizes,
            string description)
        {
            Title = title;
            Price = price;
            Sizes = sizes;
            Description = description;
        }

        [DataMember(Name = "title")]
        public string Title { get; set; }

        [DataMember(Name = "price")]
        public int Price { get; set; }

        [DataMember(Name = "sizes")]
        public ICollection<string> Sizes { get; set; }

        [DataMember(Name = "description")]
        public string Description { get; set; }
    }
}