﻿using System.Threading.Tasks;
using System.Net.Http;
using Microsoft.Extensions.Options;
using FilterApi.Models;
using Newtonsoft.Json;

namespace FilterApi.Services
{
    /// <summary>
    /// Class to commect to the http location to read the json data
    /// </summary>
    public class DataRepository : IDataRepository
    {
        private readonly DataUrlOptions _options;

        /// <summary>
        /// Constructor takes options parameter to read URL of data
        /// </summary>
        /// <param name="options"></param>
        public DataRepository(IOptions<DataUrlOptions> options)
        {
            _options = options.Value;
        }

        /// <summary>
        /// Reads the list of all products from the given URL in appsettings.json
        /// </summary>
        /// <returns>ProductsList</returns>
        public async Task<ProductsList> GetProducts()
        {
            ProductsList products = new ProductsList();

            var httpClient = HttpClientFactory.Create();
            var url = _options.Url;

            var response = await httpClient.GetAsync(url);

            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                products = JsonConvert.DeserializeObject<ProductsList>(await response.Content.ReadAsStringAsync());
            }

            return products;
        }
    }
}