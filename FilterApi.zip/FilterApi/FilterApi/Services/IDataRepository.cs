﻿using System.Threading.Tasks;
using FilterApi.Models;

namespace FilterApi.Services
{
    public interface IDataRepository
    {
        public Task<ProductsList> GetProducts();
    }
}
